﻿using System;
namespace TaxiManagementAssignment
{
	public class DropTransaction : Transaction
	{
		public int taxiNum;
		public bool priceWasPaid;
		public DropTransaction(DateTime transactionDatetime, int Numtaxi, bool Paidprice): base("Drop fare",transactionDatetime)
		{
			taxiNum = Numtaxi;
			priceWasPaid = Paidprice;

		}

        public override string ToString()
        {
			string dt = TransactionDatetime.ToString("dd/MM/yyyy HH:mm");
			if(priceWasPaid)
            {
				return (String.Format("{0} Drop fare - Taxi {1}, price was paid", dt, taxiNum));
			}
            else
            {
				return(String.Format("{0} Drop fare - Taxi {1}, price was not paid", dt, taxiNum));
			}
				
		}
    }
}

