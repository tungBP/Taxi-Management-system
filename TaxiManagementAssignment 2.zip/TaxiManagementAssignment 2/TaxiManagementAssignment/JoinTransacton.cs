﻿using System;
namespace TaxiManagementAssignment
{
	public class JoinTransaction : Transaction
	{
		public int taxiNum;
		public int rankId;
		public JoinTransaction(DateTime transactionDatetime, int Numtaxi, int Idrank): base("Join",transactionDatetime)
		{
			taxiNum = Numtaxi;
			rankId = Idrank;
		}
        public override string ToString()
        {
			string dt = TransactionDatetime.ToString("dd/MM/yyyy HH:mm");
			return (String.Format("{0} Join      - Taxi {1} in rank {2}",dt, taxiNum, rankId));
        }
    }
}

