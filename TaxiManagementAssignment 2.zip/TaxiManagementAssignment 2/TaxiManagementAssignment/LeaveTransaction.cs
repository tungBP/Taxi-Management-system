﻿using System;
namespace TaxiManagementAssignment
{
	public class LeaveTransaction : Transaction
	{
		public int taxiNum;
		public int rankId;
		public string destination;
		public double agreedPrice;
		public LeaveTransaction(DateTime transactionDatetime, int Idrank, Taxi t) : base ("Leave",transactionDatetime)
        {
			taxiNum = t.Number;
			destination = t.Destination;
			rankId = Idrank;
			agreedPrice = t.CurrentFare;
        }
        public override string ToString()
        {
			string dt = TransactionDatetime.ToString("dd/MM/yyyy HH:mm");
			return (String.Format("{0} Leave     - Taxi {1} from rank {2} to {3} for £{4}", dt, taxiNum, rankId, destination ,agreedPrice));
		}
    }

}

