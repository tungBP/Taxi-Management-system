﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiManagementAssignment
{
	public class TaxiManager
	{ 

		public SortedDictionary<int, Taxi> taxis = new SortedDictionary<int, Taxi>();
		public SortedDictionary<int, Taxi> GetAllTaxis ()
        {
			
            return taxis;
            
        }
		public Taxi FindTaxi (int taxiNum)
        {
			if (!taxis.ContainsKey(taxiNum)) //refer to taxi info if have number
            {
                return null;
            }
            else
            {
                return taxis[taxiNum];
            }
        }
        public Taxi CreateTaxi (int taxiNum)
        {
            if (!taxis.ContainsKey(taxiNum))
            {
                Taxi t = new Taxi(taxiNum); //create new taxi and add to list
                taxis.Add(taxiNum, t);
                return t;
            }
            else
            {
                return taxis[taxiNum]; //if have num return
            }


        }
	}
}

