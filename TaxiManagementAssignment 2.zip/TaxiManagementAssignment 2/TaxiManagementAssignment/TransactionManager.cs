﻿using System;
using System.Collections.Generic;
using System.Text;
namespace TaxiManagementAssignment
{
	public class TransactionManager
	{
		public List<Transaction> transactions = new List<Transaction>();
		public List<Transaction> GetAllTransactions()
        {
			return transactions;
        }
		public void RecordJoin(int taxiNum, int rankId)
        {
			DateTime now = DateTime.Now;
			JoinTransaction jt = new JoinTransaction(now, taxiNum, rankId);
			transactions.Add(jt);
        }
		public void RecordLeave(int taxiNum,  Taxi t)
        {
			DateTime now = DateTime.Now;
			LeaveTransaction lt = new LeaveTransaction(now, taxiNum, t);
			transactions.Add(lt);
        }
		public void RecordDrop(int taxiNum, bool pricePaid)
        {
			DateTime now = DateTime.Now;
			DropTransaction dt = new DropTransaction(now, taxiNum, pricePaid);
			transactions.Add(dt);
        }
	}
}

