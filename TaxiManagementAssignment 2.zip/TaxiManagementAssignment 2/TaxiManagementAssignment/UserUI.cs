﻿using System;
using System.Collections.Generic;
using System.Text;
namespace TaxiManagementAssignment
{
	public class UserUI
	{
		public RankManager rankMgr;
		public TaxiManager taxiMgr;
		public TransactionManager transactionMgr;
		public UserUI(RankManager rkMgr, TaxiManager txMgr, TransactionManager trMgr)
        {
			rankMgr = rkMgr;
			taxiMgr = txMgr;
			transactionMgr = trMgr;
        }
		public List<string> TaxiJoinsRank(int taxiNum, int rankId)// join rank to dropfare
		{
			List<string> JoinsRank = new List<string>();
			Taxi t = taxiMgr.CreateTaxi(taxiNum);
			if (rankMgr.AddTaxiToRank(t, rankId)) //to rankmanager then to rank
			{
				transactionMgr.RecordJoin(taxiNum, rankId); //if success, join transaction recorded
				JoinsRank.Add(String.Format("Taxi {0} has joined rank {1}.", taxiNum, rankId));

			}
			else
            {
				JoinsRank.Add(String.Format("Taxi {0} has not joined rank {1}.", taxiNum, rankId));
			}
			return JoinsRank;


        }

		public List<string> TaxiLeavesRank(int rankId, string destination, double agreedPrice)
        {
			List<string> LeavesRank = new List<string>();
			Taxi t = rankMgr.FrontTaxiInRankTakesFare(rankId, destination, agreedPrice);
			if (t == null)
			{
				LeavesRank.Add(String.Format("Taxi has not left rank 1.",rankId));
			}
			else
			{
				
				transactionMgr.RecordLeave(rankId, t);
				LeavesRank.Add(String.Format("Taxi {0} has left rank {1} to take a fare to {2} for £{3}.", t.Number, rankId, destination , agreedPrice));

			}

			return LeavesRank;
        }

		public List<string> TaxiDropsFare(int taxiNum, bool pricePaid)
        {
			List<string> DropsFare = new List<string>();
			Taxi t = taxiMgr.FindTaxi(taxiNum);
			if (t.Location == "in rank") // false
			{
				DropsFare.Add(String.Format("Taxi {0} has not dropped its fare.", t.Number));
			}
            else
            {
				
				if (!pricePaid)
				{
					DropsFare.Add(String.Format("Taxi {0} has dropped its fare and the price was not paid.", t.Number));
					transactionMgr.RecordDrop(taxiNum, pricePaid);
				}
				else
				{
					t.DropFare(pricePaid);
					DropsFare.Add(String.Format("Taxi {0} has dropped its fare and the price was paid.", t.Number));
					transactionMgr.RecordDrop(taxiNum, pricePaid);
				}
				
			}
            
			return DropsFare;


		
        }
		public List<string> ViewTaxiLocations() 
        {
			List<string> TaxiLocations = new List<string>();
			SortedDictionary<int, Taxi> gettaxi = taxiMgr.GetAllTaxis();
			TaxiLocations.Add("Taxi locations");
			TaxiLocations.Add("==============");
			if (gettaxi.Count == 0)
            {
			
				TaxiLocations.Add("No taxis");
			}
            else
            {
				foreach (int i in gettaxi.Keys)
                {
					Taxi t = taxiMgr.GetAllTaxis()[i];//get taxi using index i
					if (t.Location == "in rank")
                    {
						TaxiLocations.Add(String.Format("Taxi {0} is in rank {1}", t.Number, t.Rank.Id));
					}
					if (t.Location == "on the road")
                    {
						if (t.Destination != "")
                        {
							TaxiLocations.Add(String.Format("Taxi {0} is on the road to {1}", t.Number, t.Destination));
						}
						else
                        {
							TaxiLocations.Add(String.Format("Taxi {0} is on the road", t.Number ));
						}
                    }
				
					
				}
            }

			return TaxiLocations;


		}
		public List<string> ViewFinancialReport()
        {
			List<string> FinancialReport = new List<string>();
			SortedDictionary<int, Taxi> gettaxi = taxiMgr.GetAllTaxis();
			double total = 0;
			FinancialReport.Add("Financial report");
			FinancialReport.Add("================");
			if (gettaxi.Count == 0)
			{
				FinancialReport.Add("No taxis, so no money taken");
			}
			else
			{
				foreach (int i in gettaxi.Keys)
				{

					Taxi t = taxiMgr.GetAllTaxis()[i];
					total = total + t.TotalMoneyPaid;
					FinancialReport.Add(String.Format("Taxi {0}      {1:0.00}", t.Number, t.TotalMoneyPaid));
					



				}
				FinancialReport.Add("           ======");
				FinancialReport.Add(String.Format("Total:       {0:0.00}", total));
				FinancialReport.Add("           ======");
			}
			return FinancialReport;
		}
		public List<string> ViewTransactionLog()
        {
			List<string> TransactionLog = new List<string>();
			List<Transaction> gettransaction = transactionMgr.GetAllTransactions();
			TransactionLog.Add("Transaction report");
			TransactionLog.Add("==================");
			if (gettransaction.Count == 0)
            {
				TransactionLog.Add("No transactions");
			}
			foreach (Transaction type in gettransaction)
            {
				TransactionLog.Add(type.ToString());
            }

			return TransactionLog;
        }
	}
}

