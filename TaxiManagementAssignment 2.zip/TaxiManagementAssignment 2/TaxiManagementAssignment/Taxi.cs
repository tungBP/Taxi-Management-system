﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiManagementAssignment
{
    public class Taxi
    {
        public int Number;
        public static string IN_RANK = "in rank";
        public static string ON_ROAD = "on the road";
        public double CurrentFare = 0; //02
        public string Destination = ""; //03
        public string Location = ON_ROAD; //04
        public double TotalMoneyPaid = 0; //06
        private Rank rank;
        public Rank Rank
        {
            get
            {
                return rank;
            }
            
            set
            {
                

                if (value == null) //05
                {
                    throw new Exception("Rank cannot be null"); //07 08
                }
                if (Destination != "")
                {
                    throw new Exception("Cannot join rank if fare has not been dropped");
                }
                else
                {
                    rank = value;
                    Location = IN_RANK;
                }
            

            }

        }
        //01
        public Taxi(int num)
        {
            Number = num;
        }

        public void AddFare(string destination, double agreedPrice)
        {
            rank = null;
            Destination = destination;
            CurrentFare = agreedPrice;
            Location = ON_ROAD;
      
            
        }

        public void DropFare(bool priceWasPaid) 
        {
            if (priceWasPaid) //auto true
            {
                TotalMoneyPaid = CurrentFare + TotalMoneyPaid;
                Destination = "";
                CurrentFare = 0;
              
            }
            else
            {
                TotalMoneyPaid = 0;

            }

           
        }

    }
}
