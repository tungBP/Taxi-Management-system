﻿   using System;
using System.Collections.Generic;
using System.Text;
namespace TaxiManagementAssignment
{
	public class Rank
	{
		public int Id;
		public int NumberOfTaxiSpaces;
		public List<Taxi> TaxiSpace = new List<Taxi>(); //create a list
		public Rank(int rankId, int taxiSpaces)
		{
			Id = rankId;
			NumberOfTaxiSpaces = taxiSpaces;

		}

		public bool AddTaxi (Taxi t)
        {
			
			if (NumberOfTaxiSpaces == 0) //no spare space
			{ 
				return false;
            }
            else
            {
				t.Rank = this;
				TaxiSpace.Add(t); //add into the list
				NumberOfTaxiSpaces--;
				return true;

            }



		}
		public Taxi FrontTaxiTakesFare(string Destination, double agreedPrice)
		{
			if (TaxiSpace.Count != 0)
			{
				Taxi t = TaxiSpace[0];//first taxi is first out
				t.AddFare(Destination, agreedPrice);
				TaxiSpace.RemoveAt(0);
				NumberOfTaxiSpaces++;
				return t;

			}

			else
			{
				return null;
			}
		}
	}
}
